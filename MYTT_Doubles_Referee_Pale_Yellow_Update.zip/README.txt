MYTT Smart Draw — Doubles Referee Colour Update

Upload smart-draw-test.html to the same GitHub folder as the current test page and replace the existing file.
Commit the change, then hard-refresh https://mytt.my/smart-draw-test.html.

Change scope:
- Doubles referee labels and names use the existing pale-yellow theme colour.
- Doubles All Match Order referee cells use the same pale-yellow colour.
- Singles styles, draw logic, scores, BO3/BO5 validation, and Apps Script are unchanged.
