MYTT Smart Draw – Doubles Animation V5

This update restores the same red progress bar and green settled team names used by Singles.
Only the Doubles draw animation behavior is changed: the progress bar advances smoothly, final team names receive the existing .settled green style, and the panel/slots remain stable.

Deployment: replace smart-draw-test.html in the same GitHub folder with this file renamed to smart-draw-test.html, then commit. No Apps Script redeployment is required.
